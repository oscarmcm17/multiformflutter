package com.example.examen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
