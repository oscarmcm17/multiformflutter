import 'package:flutter/material.dart';

class Bienvenida extends StatelessWidget {
  const Bienvenida({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Material App',
      theme: ThemeData(
        primaryColor:
            Colors.blue, // Cambia el color de fondo de la barra de navegación
        scaffoldBackgroundColor:
            Colors.white, // Cambia el color de fondo del cuerpo de la pantalla
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Bienvenida'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.thumb_up,
                color: Colors.green,
                size: 100,
              ),
              Text(
                '¡Usuario válido!',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
