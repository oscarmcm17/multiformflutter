import 'package:flutter/material.dart';
import 'bienvenida.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  MyApp({Key? key});

  // Variables para identificar los campos de texto
  var txtLogin = TextEditingController();
  var txtPass = TextEditingController();

  // Método para construir el conjunto de Widgets de la app
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multiformularios',
      theme: ThemeData.light(),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Multiformularios'),
        ),
        body: Column(
          children: [
            // Imagen
            Padding(
              padding: EdgeInsets.all(40),
              child: Center(
                child: Image.asset(
                  "img/usuario.png",
                  width: 100,
                ),
              ),
            ),
            // Campo de texto para el login
            Padding(
              padding: EdgeInsets.all(20),
              child: TextField(
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                ),
                decoration: InputDecoration(
                  hintText: "Login",
                ),
                // Nombramos el campo de texto
                controller: txtLogin,
              ),
            ),

            // Campo de texto para el password
            Padding(
              padding: EdgeInsets.all(20),
              child: TextField(
                // pone asteriscos
                obscureText: true,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                ),
                decoration: InputDecoration(
                  hintText: "Password",
                ),
                // Nombramos el campo de texto
                controller: txtPass,
              ),
            ),

            // El botón
            Padding(
              padding: EdgeInsets.all(20),
              child: Builder(
                builder: (BuildContext context) {
                  return ElevatedButton.icon(
                    icon: Icon(Icons.login),
                    label: Text("Validar Usuario"),
                    onPressed: () {
                      // Verificar el usuario y contraseña
                      bool isValid =
                          validarUsuario(txtLogin.text, txtPass.text);

                      // Mostrar el resultado en un cuadro de diálogo
                      showDialog(
                        context: context, // Usa el context del Material App
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text('Resultado de Validación'),
                            content: isValid
                                ? Column(
                                    children: [
                                      Icon(
                                        Icons.check_circle,
                                        color: Colors.green,
                                        size: 50,
                                      ),
                                      Text('Usuario válido'),
                                    ],
                                  )
                                : Column(
                                    children: [
                                      Icon(
                                        Icons.cancel,
                                        color: Colors.red,
                                        size: 50,
                                      ),
                                      Text('Usuario no válido'),
                                    ],
                                  ),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Text('Cerrar'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  // Método para validar el usuario (puedes cambiar la lógica según tus necesidades)
  bool validarUsuario(String login, String password) {
    // Valores predeterminados para la validación
    const String usuarioCorrecto = 'usuario';
    const String contrasenaCorrecta = 'contraseña';

    // Comparar con los valores predeterminados
    return login == usuarioCorrecto && password == contrasenaCorrecta;
  }
}
